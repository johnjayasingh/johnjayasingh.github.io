import { SearchItsiPage } from './app.po';

describe('search-itsi App', () => {
  let page: SearchItsiPage;

  beforeEach(() => {
    page = new SearchItsiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
