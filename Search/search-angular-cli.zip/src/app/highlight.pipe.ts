import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'highlight'
})
export class HighlightPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let index = value.toUpperCase().indexOf(args.toUpperCase());
    let finalString = value.substring(0, index) +
      "<span class='highlight'>" + value.substring(index, index + args.length) + "</span>" +
      value.substring(index + args.length);
    console.log(finalString);
    return finalString;
  }

}
