import { Injectable } from '@angular/core';
import { Http } from '@angular/http'

import 'rxjs/add/operator/toPromise';

@Injectable()
export class ProjectService {
  // Dev URL
  url = "/assets/data.json";

  constructor(private http: Http) { }

  getProjects(): Promise<any[]> {
    return this.http.get(this.url)
      .toPromise()
      .then(response => response.json() as any[])
  }
}
