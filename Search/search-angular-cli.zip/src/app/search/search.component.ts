import { Component, OnInit } from '@angular/core';

import { ProjectService } from '../project.service';

@Component({
  selector: 'custom-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  searchVal:string="";
  projects: any[] = [];
  constructor(private projectService: ProjectService) {
  }

  ngOnInit() {
    this.projectService
      .getProjects()
      .then(response => this.projects = response);
  }
  KeyPress($event){
    //console.log($event);
  }

}
